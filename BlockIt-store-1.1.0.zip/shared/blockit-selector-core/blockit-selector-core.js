/*
 * Authoritative syntax core for selector-like BlockIt rules.
 * It deliberately has no dependency on Chrome APIs or a particular document.
 * Consumers provide the DOM environment and use the parsed CSS plus filters.
 */
(() => {
  const SYNTAX_VERSION = 1;
  const CUSTOM_NAMES = new Set([
    'attr-name', 'attr', 'text', 'own-text', 'html', 'class-name', 'attrs',
    'within', 'near', 'children', 'accessible', 'visible', 'size', 'style', 'style-property',
    'property', 'in-frame', 'in-shadow', 'frame-has', 'has-frame',
    'class-count', 'attribute-count', 'attr-count', 'matches-position', 'sibling-position', 'sibling-distance',
    'text-starts', 'text-ends', 'text-contains', 'text-matches',
    'own-text-starts', 'own-text-ends', 'own-text-contains', 'own-text-matches',
    'has'
  ]);

  function normalizeCssSelector(selector) {
    return String(selector).replace(/(['"])\[([^\]\n]+)\]\((https?:\/\/[^)\s]+)\)\1/g, '$1$2$1');
  }

  function looksLikeCssSelector(selector) {
    const value = String(selector).trim();
    return /^[a-zA-Z*][\w-]*(?:\s|[.#[:>+~]|$)/.test(value);
  }

  function readCall(text, start) {
    let depth = 1, quote = '', escaped = false, regex = false;
    for (let index = start; index < text.length; index++) {
      const char = text[index];
      if (quote) {
        if (escaped) escaped = false;
        else if (char === '\\') escaped = true;
        else if (char === quote) quote = '';
        continue;
      }
      if (char === '"' || char === "'") { quote = char; continue; }
      if (char === '/') {
        if (regex && text[index - 1] !== '\\') { regex = false; continue; }
        if (!regex && (index === start || /[(:,=\s]/.test(text[index - 1]))) { regex = true; continue; }
      }
      if (regex) continue;
      if (char === '(') depth++;
      if (char === ')' && --depth === 0) return { value: text.slice(start, index), end: index + 1 };
    }
    throw new Error('Unclosed BlockIt pseudo class');
  }

  function parseCompound(selector) {
    const filters = [];
    let css = '', index = 0, quote = '', bracketDepth = 0;
    const source = String(selector || '');
    while (index < source.length) {
      const char = source[index];
      if (!quote && char === '\\') { css += char + (source[index + 1] || ''); index += 2; continue; }
      if (quote) {
        css += char;
        if (char === '\\') css += source[++index] || '';
        else if (char === quote) quote = '';
        index++; continue;
      }
      if (char === '"' || char === "'") { quote = char; css += char; index++; continue; }
      if (char === '[') { bracketDepth++; css += char; index++; continue; }
      if (char === ']') { bracketDepth--; css += char; index++; continue; }
      if (!bracketDepth && char === ':') {
        const match = source.slice(index + 1).match(/^([a-z-]+)\(/i);
        if (match && (CUSTOM_NAMES.has(match[1]) || ['is', 'where', 'not'].includes(match[1]))) {
          const name = match[1];
          const call = readCall(source, index + 2 + name.length);
          filters.push({ name, value: call.value.trim() });
          index = call.end; continue;
        }
        // Native functional pseudo classes are opaque to the rule parser.
        if (match) {
          const call = readCall(source, index + 2 + match[1].length);
          css += source.slice(index, call.end); index = call.end; continue;
        }
      }
      css += char; index++;
    }
    css = css.trim() || '*';
    css = css.replace(/\[([a-zA-Z_][\w-]*)-\*(?:(\^=|\$=|\*=|~=|\|=|=)(?:"([^"]*)"|'([^']*)'|([^\]]+)))?\]/g,
      (_, prefix, operator, doubleQuoted, singleQuoted, bare) => {
        filters.push({ name: 'attr-wildcard', prefix: `${prefix}-`, operator: operator || '', expected: doubleQuoted ?? singleQuoted ?? bare ?? '' });
        return '';
      });
    return { css: css.trim() || '*', filters };
  }

  const compiled = new Map();
  function branchesFor(selector) {
    const source = String(selector || '').trim();
    if (!source) throw new Error('Empty selector');
    if (compiled.has(source)) return compiled.get(source);
    const branches = splitArgs(source).map(branch => {
      const steps = []; let buffer = '', relation = ' ', bracket = 0, quote = '';
      const flush = () => { if (buffer.trim()) { steps.push({ relation, ...parseCompound(buffer.trim()) }); buffer = ''; relation = ' '; } };
      for (let i = 0; i < branch.length; i++) {
        const char = branch[i];
        if (char === '\\') { buffer += char + (branch[++i] || ''); continue; }
        if (quote) { buffer += char; if (char === quote) quote = ''; continue; }
        if (char === '"' || char === "'") { quote = char; buffer += char; continue; }
        if (char === '[') bracket++;
        if (char === ']') bracket--;
        if (!bracket && char === '(') { const call = readCall(branch, i + 1); buffer += branch.slice(i, call.end); i = call.end - 1; continue; }
        if (!bracket && /\s/.test(char)) { flush(); continue; }
        if (!bracket && '>+~'.includes(char)) { flush(); if (relation !== ' ') throw new Error('Invalid combinator'); relation = char; continue; }
        buffer += char;
      }
      flush();
      if (!steps.length || relation !== ' ' || bracket || quote) throw new Error('Incomplete selector');
      return steps;
    });
    if (compiled.size >= 256) compiled.clear();
    compiled.set(source, branches); return branches;
  }

  function parse(selector) {
    const branches = branchesFor(selector);
    if (branches.length === 1 && branches[0].length === 1) {
      const { css, filters } = branches[0][0]; return { css, filters };
    }
    const css = branches.map(steps => steps.map((step, i) => `${i ? step.relation : ''} ${step.css}`).join(' ').trim()).join(', ');
    return { css, filters: branches.some(steps => steps.some(step => step.filters.length))
      ? [{ name: 'selector-tree', branches }] : [] };
  }

  function isBlockItRule(selector) {
    try {
      const filters = parse(selector).filters;
      /* Native :has() is valid CSS. It becomes a BlockIt rule only when its
         nested selector itself contains a BlockIt-only condition. */
      const custom = filter => filter.name === 'selector-tree'
        ? filter.branches.some(steps => steps.some(step => step.filters.some(custom)))
        : ['has', 'is', 'where', 'not'].includes(filter.name) ? isBlockItRule(filter.value) : true;
      return filters.some(custom);
    } catch { return false; }
  }

  function splitArgs(value) {
    const parts = [], start = { at: 0 };
    let depth = 0, quote = '', inRegex = false, escaped = false;
    for (let index = 0; index <= value.length; index++) {
      const char = value[index] || ',';
      if (!quote && char === '\\') { index++; continue; }
      if (quote) {
        if (escaped) escaped = false;
        else if (char === '\\') escaped = true;
        else if (char === quote) quote = '';
        continue;
      }
      if (char === '"' || char === "'") { quote = char; continue; }
      if (char === '/') {
        if (inRegex && value[index - 1] !== '\\') { inRegex = false; continue; }
        if (!inRegex && (index === 0 || /[,(=\s]/.test(value[index - 1]))) { inRegex = true; continue; }
      }
      if (inRegex) continue;
      if (char === '(' || char === '[') depth++;
      else if (char === ')' || char === ']') depth--;
      else if (char === ',' && depth === 0) { parts.push(value.slice(start.at, index).trim()); start.at = index + 1; }
    }
    return parts.filter(Boolean);
  }

  function regex(value) {
    const match = String(value).trim().match(/^\/((?:\\.|[^/])*)\/([dgimsuvy]*)$/);
    if (!match) throw new Error('Expected /regular expression/');
    return new RegExp(match[1], match[2]);
  }

  function compareCount(count, expression) {
    const match = String(expression).trim().match(/^(<=|>=|=|<|>)?\s*(\d+)$/);
    if (!match) throw new Error('Expected count such as >=1');
    const expected = Number(match[2]), operator = match[1] || '=';
    return ({ '<': count < expected, '<=': count <= expected, '=': count === expected, '>=': count >= expected, '>': count > expected })[operator];
  }

  function textOf(element, ownOnly) {
    if (!ownOnly) return (element.textContent || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    return [...element.childNodes].filter(node => node.nodeType === 3)
      .map(node => node.textContent).join(' ').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function textMatches(actual, expression, mode = 'exact') {
    const source = String(expression || '').trim();
    if (mode === 'regex' || /^\/.+\/[dgimsuvy]*$/.test(source)) {
      try { return regex(source).test(actual); } catch { return false; }
    }
    let expected = source.replace(/^['"]|['"]$/g, '');
    if (source.startsWith('"')) { try { expected = JSON.parse(source); } catch {} }
    if (mode === 'prefix') return actual.startsWith(expected);
    if (mode === 'suffix') return actual.endsWith(expected);
    if (mode === 'contains') return actual.includes(expected);
    return actual === expected;
  }

  function styleHasProperty(value, property) {
    const wanted = String(property || '').trim().toLowerCase();
    if (!wanted) return false;
    return String(value || '').split(';').some(declaration => {
      const index = declaration.indexOf(':');
      return index > 0 && declaration.slice(0, index).trim().toLowerCase() === wanted;
    });
  }

  function parsePositionList(value) {
    return [...new Set(String(value || '').split(/[,;\s]+/)
      .map(Number).filter(position => Number.isInteger(position) && position > 0))];
  }

  /* Snapshot-compatible evaluator. It intentionally refuses filters which
     require live browser state (layout, computed styles, JS properties or a
     cross-origin frame document) instead of silently giving another meaning. */
  function matchFilter(element, filter, options) {
    const value = filter.value;
    if (filter.name === 'selector-tree') return filter.branches.some(steps => matchChain(element, steps, steps.length - 1, options || {}));
    if (['is', 'where', 'not'].includes(filter.name)) {
      const result = matches(element, value, options);
      return filter.name === 'not' ? !result : result;
    }
    if (filter.name === 'attr-wildcard') return [...element.attributes].some(attr => {
      if (!attr.name.startsWith(filter.prefix)) return false;
      if (!filter.operator) return true;
      if (filter.operator === '=') return attr.value === filter.expected;
      if (filter.operator === '^=') return attr.value.startsWith(filter.expected);
      if (filter.operator === '$=') return attr.value.endsWith(filter.expected);
      if (filter.operator === '*=') return attr.value.includes(filter.expected);
      if (filter.operator === '~=') return attr.value.split(/\s+/).includes(filter.expected);
      return attr.value === filter.expected || attr.value.startsWith(`${filter.expected}-`);
    });
    if (filter.name === 'attr-name') return [...element.attributes].some(attr => regex(value).test(attr.name));
    if (filter.name === 'attr') {
      const [name, attrValue] = splitArgs(value);
      return Boolean(name && attrValue && [...element.attributes].some(attr => regex(name).test(attr.name) && regex(attrValue).test(attr.value)));
    }
    if (filter.name === 'style-property') return styleHasProperty(element.getAttribute?.('style'), value.replace(/^['"]|['"]$/g, ''));
    if (filter.name === 'class-count') return compareCount(element.classList.length, value);
    if (filter.name === 'attribute-count' || filter.name === 'attr-count') return compareCount(element.attributes.length, value);
    if (filter.name === 'sibling-position') return parsePositionList(value).includes([...(element.parentNode?.children || [])].indexOf(element) + 1);
    if (filter.name === 'sibling-distance') {
      const [directionValue, distanceValue, siblingSelector] = splitArgs(value);
      const direction = String(directionValue || '').trim().toLowerCase();
      const distance = Number(distanceValue);
      if (!['previous', 'next'].includes(direction) || !Number.isInteger(distance) || distance < 1 || !siblingSelector) {
        throw new Error('Expected sibling-distance(previous|next, positive integer, selector)');
      }
      let sibling = element;
      for (let step = 0; step < distance && sibling; step++) {
        sibling = direction === 'previous' ? sibling.previousElementSibling : sibling.nextElementSibling;
      }
      return Boolean(sibling && matches(sibling, siblingSelector, options));
    }
    if (filter.name === 'matches-position') return true;
    if (filter.name === 'text') return textMatches(textOf(element, false), value);
    if (filter.name === 'own-text') return textMatches(textOf(element, true), value);
    if (filter.name === 'text-starts') return textMatches(textOf(element, false), value, 'prefix');
    if (filter.name === 'text-ends') return textMatches(textOf(element, false), value, 'suffix');
    if (filter.name === 'text-contains') return textMatches(textOf(element, false), value, 'contains');
    if (filter.name === 'text-matches') return textMatches(textOf(element, false), value, 'regex');
    if (filter.name === 'own-text-starts') return textMatches(textOf(element, true), value, 'prefix');
    if (filter.name === 'own-text-ends') return textMatches(textOf(element, true), value, 'suffix');
    if (filter.name === 'own-text-contains') return textMatches(textOf(element, true), value, 'contains');
    if (filter.name === 'own-text-matches') return textMatches(textOf(element, true), value, 'regex');
    if (filter.name === 'has') return matchHas(element, value, options);
    if (filter.name === 'html') return regex(value).test(element.outerHTML);
    if (filter.name === 'class-name') return [...element.classList].some(name => regex(value).test(name));
    if (filter.name === 'attrs') return splitArgs(value.trim().replace(/^\[\s*|\s*\]$/g, '')).every(term => term.startsWith('/')
      ? [...element.attributes].some(attr => regex(term).test(attr.name))
      : element.hasAttribute(term.replace(/^['"]|['"]$/g, '')));
    if (filter.name === 'within') {
      for (let parent = element.parentElement || element.getRootNode()?.host; parent;
        parent = parent.parentElement || parent.getRootNode()?.host) if (matches(parent, value, options)) return true;
      return false;
    }
    if (filter.name === 'near') return [...(element.parentNode?.children || [])].some(sibling => sibling !== element && matches(sibling, value, options));
    if (filter.name === 'children') {
      const [childSelector, amount = '>=1'] = splitArgs(value);
      return Boolean(childSelector) && compareCount([...element.children].filter(child => matches(child, childSelector, options)).length, amount);
    }
    if (['visible', 'size', 'style', 'property', 'accessible', 'in-frame', 'in-shadow', 'frame-has', 'has-frame'].includes(filter.name)) {
      if (options?.runtimeFilter) return options.runtimeFilter(element, filter);
      options?.unsupported?.add(filter.name); return false;
    }
    return true;
  }

  function matchHas(element, value, options) {
    const forward = (anchor, steps, i) => {
      const step = steps[i]; let candidates = [];
      if (step.relation === '>') candidates = [...anchor.children];
      else if (step.relation === '+') candidates = anchor.nextElementSibling ? [anchor.nextElementSibling] : [];
      else if (step.relation === '~') { for (let n = anchor.nextElementSibling; n; n = n.nextElementSibling) candidates.push(n); }
      else candidates = [...anchor.querySelectorAll(step.css)];
      const matched = candidates.filter(n => matchesCompound(n, step, options || {}));
      const positions = step.filters.filter(f => f.name === 'matches-position');
      return matched.some((n, position) => positions.every(f => parsePositionList(f.value).includes(position + 1)) &&
        (i === steps.length - 1 || forward(n, steps, i + 1)));
    };
    return branchesFor(value).some(steps => forward(element, steps, 0));
  }

  function matchesCompound(element, step, options) {
    return element.matches(step.css) && step.filters.filter(f => f.name !== 'matches-position').every(f => matchFilter(element, f, options));
  }

  function matchChain(element, steps, index, options) {
    if (!element || !matchesCompound(element, steps[index], options)) return false;
    if (index > 0) {
      const relation = steps[index].relation;
      let found = false;
      if (relation === '>') found = matchChain(element.parentElement, steps, index - 1, options);
      else if (relation === '+') found = matchChain(element.previousElementSibling, steps, index - 1, options);
      else for (let n = relation === '~' ? element.previousElementSibling : element.parentElement; n;
        n = relation === '~' ? n.previousElementSibling : n.parentElement) {
        if (matchChain(n, steps, index - 1, options)) { found = true; break; }
      }
      if (!found) return false;
    }
    const positions = steps[index].filters.filter(f => f.name === 'matches-position');
    if (!positions.length || options.skipPosition === steps[index]) return true;
    const scopes = options.scopes || [element.getRootNode()];
    const candidates = [...new Set(scopes.flatMap(scope => [...scope.querySelectorAll(steps[index].css)]))]
      .filter(n => matchChain(n, steps, index, { ...options, skipPosition: steps[index] }));
    return positions.every(f => parsePositionList(f.value).includes(candidates.indexOf(element) + 1));
  }

  function matches(element, selector, options = {}) {
    const branches = branchesFor(selector);
    try { return branches.some(steps => matchChain(element, steps, steps.length - 1, options)); }
    catch { return false; }
  }

  function findInScopes(selector, scopes, options = {}) {
    const branches = branchesFor(selector);
    const query = branches.map(steps => steps.at(-1).css).join(', ');
    const candidates = [...new Set((scopes || []).flatMap(scope => [...scope.querySelectorAll(query)]))];
    const accepted = new Set();
    for (const steps of branches) {
      const last = steps.at(-1), context = { ...options, scopes, skipPosition: last };
      const matches = candidates.filter(n => matchChain(n, steps, steps.length - 1, context));
      const positions = last.filters.filter(f => f.name === 'matches-position');
      matches.forEach((n, i) => { if (positions.every(f => parsePositionList(f.value).includes(i + 1))) accepted.add(n); });
    }
    return candidates.filter(n => accepted.has(n));
  }

  globalThis.__blockItSelectorCore = {
    SYNTAX_VERSION, CUSTOM_NAMES, normalizeCssSelector, looksLikeCssSelector, parse, isBlockItRule,
    splitArgs, matchFilter, matches, findInScopes
  };
})();
