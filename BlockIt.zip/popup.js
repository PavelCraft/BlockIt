// ===== Функция локализации =====
function localizeUI() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const message = chrome.i18n.getMessage(key);
    if (message) {
      el.textContent = message;
    }
  });
  
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    const message = chrome.i18n.getMessage(key);
    if (message) {
      el.placeholder = message;
    }
  });
  
  // Локализуем заглушку для тега, если он ещё не задан
  if (!currentTag) {
    const tagDisplay = document.getElementById('tagDisplay');
    const message = chrome.i18n.getMessage('tagNotDefined');
    if (message) {
      tagDisplay.textContent = message;
    }
  }
  
  // Локализуем подсказку режима блокировки
  updateModeHint();
}

// ===== Обновление подсказки режима блокировки =====
function updateModeHint() {
  const hint = document.getElementById('modeHint');
  const selectedRadio = document.querySelector('input[name="blockMode"]:checked');
  if (selectedRadio) {
    const mode = selectedRadio.value;
    const key = mode === 'remove' ? 'modeRemoveHint' : 'modeHideHint';
    const message = chrome.i18n.getMessage(key);
    if (message) {
      hint.textContent = message;
    }
  }
}

// ===== Парсер без регулярок =====
function parseOuterTag(html) {
  let i = 0;
  const len = html.length;
  
  while (i < len && html[i] !== '<') i++;
  if (i >= len) return null;
  i++;
  
  let tag = '';
  while (i < len && html[i] !== ' ' && html[i] !== '>') {
    tag += html[i];
    i++;
  }
  if (!tag) return null;
  
  const attributes = {};
  while (i < len && html[i] !== '>') {
    while (i < len && html[i] === ' ') i++;
    if (i >= len || html[i] === '>') break;
    
    let attrName = '';
    while (i < len && html[i] !== '=' && html[i] !== ' ') {
      attrName += html[i];
      i++;
    }
    if (!attrName) break;
    
    while (i < len && html[i] !== '"' && html[i] !== "'") i++;
    if (i >= len) break;
    const quote = html[i];
    i++;
    
    let attrValue = '';
    while (i < len && html[i] !== quote) {
      attrValue += html[i];
      i++;
    }
    if (i < len) i++;
    
    attributes[attrName] = attrValue;
  }
  
  return { tag, attributes };
}

// ===== Сборка селектора =====
function buildSelector(tag, attributes) {
  let selector = tag;
  for (const [key, value] of Object.entries(attributes)) {
    selector += `[${key}="${value}"]`;
  }
  return selector;
}

// ===== Состояние =====
let currentTag = '';
let currentAttributes = {};

// ===== Отображение атрибутов с кнопками редактирования/удаления =====
function renderAttributes(tag, attributes) {
  const container = document.getElementById('attributesContainer');
  container.innerHTML = '';
  
  const keys = Object.keys(attributes);
  if (keys.length === 0) {
    const emptyMsg = document.createElement('div');
    emptyMsg.style.color = '#999';
    emptyMsg.style.fontStyle = 'italic';
    emptyMsg.textContent = chrome.i18n.getMessage('noAttributes');
    container.appendChild(emptyMsg);
    return;
  }
  
  for (const [key, value] of Object.entries(attributes)) {
    const div = document.createElement('div');
    div.className = 'attr-item';
    
    const nameSpan = document.createElement('span');
    nameSpan.className = 'attr-name';
    nameSpan.textContent = key;
    
    const valueSpan = document.createElement('span');
    valueSpan.className = 'attr-value';
    valueSpan.textContent = `="${value}"`;
    
    const editBtn = document.createElement('button');
    editBtn.className = 'attr-edit';
    editBtn.textContent = '✏️';
    editBtn.title = chrome.i18n.getMessage('editAttrTitle');
    editBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      const promptMsg = chrome.i18n.getMessage('editAttrPrompt').replace('{key}', key);
      const newValue = prompt(promptMsg, value);
      if (newValue !== null && newValue.trim() !== '') {
        attributes[key] = newValue.trim();
        renderAttributes(tag, attributes);
        updateSelector(tag, attributes);
      }
    });
    
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'attr-delete';
    deleteBtn.textContent = '🗑️';
    deleteBtn.title = chrome.i18n.getMessage('deleteAttrTitle');
    deleteBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      delete attributes[key];
      renderAttributes(tag, attributes);
      updateSelector(tag, attributes);
    });
    
    div.appendChild(nameSpan);
    div.appendChild(valueSpan);
    div.appendChild(editBtn);
    div.appendChild(deleteBtn);
    container.appendChild(div);
  }
}

// ===== Обновление селектора =====
function updateSelector(tag, attributes) {
  const selector = buildSelector(tag, attributes);
  document.getElementById('selectorInput').value = selector;
  currentTag = tag;
  currentAttributes = attributes;
  
  checkSelectorCount(selector);
}

// ===== Проверка количества элементов =====
function checkSelectorCount(selector) {
  const countSpan = document.getElementById('elementCount');
  
  if (!selector || selector.trim() === '') {
    countSpan.textContent = '🔍 ' + chrome.i18n.getMessage('enterSelector');
    countSpan.style.color = '#999';
    return;
  }
  
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs || !tabs[0]) {
      countSpan.textContent = '⚠️ ' + chrome.i18n.getMessage('checkError');
      countSpan.style.color = 'orange';
      return;
    }
    
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (sel) => {
        try {
          return document.querySelectorAll(sel).length;
        } catch (e) {
          return -1;
        }
      },
      args: [selector]
    }, function(results) {
      if (chrome.runtime.lastError) {
        countSpan.textContent = '⚠️ ' + chrome.i18n.getMessage('checkError');
        countSpan.style.color = 'orange';
        return;
      }
      
      const count = results && results[0] ? results[0].result : -1;
      
      if (count === -1) {
        countSpan.textContent = chrome.i18n.getMessage('selectorInvalid');
        countSpan.style.color = 'red';
      } else if (count === 0) {
        countSpan.textContent = chrome.i18n.getMessage('foundZero');
        countSpan.style.color = 'orange';
      } else if (count === 1) {
        countSpan.textContent = chrome.i18n.getMessage('foundOne');
        countSpan.style.color = 'green';
      } else {
        const msg = chrome.i18n.getMessage('foundMultiple').replace('{count}', count);
        countSpan.textContent = msg;
        countSpan.style.color = 'red';
      }
    });
  });
}

// ===== Обработка вставленного HTML =====
document.getElementById('parseBtn').addEventListener('click', function() {
  const html = document.getElementById('htmlInput').value.trim();
  if (!html) {
    alert(chrome.i18n.getMessage('alertPasteHtml'));
    return;
  }
  
  const parsed = parseOuterTag(html);
  if (!parsed || !parsed.tag) {
    alert(chrome.i18n.getMessage('alertParseError'));
    return;
  }
  
  currentTag = parsed.tag;
  currentAttributes = parsed.attributes;
  
  document.getElementById('tagDisplay').textContent = currentTag;
  renderAttributes(currentTag, currentAttributes);
  updateSelector(currentTag, currentAttributes);
});

// ===== Добавление нового атрибута вручную =====
document.getElementById('addAttrBtn').addEventListener('click', function() {
  const nameInput = document.getElementById('newAttrName');
  const valueInput = document.getElementById('newAttrValue');
  const name = nameInput.value.trim();
  const value = valueInput.value.trim();
  
  if (!name) {
    alert(chrome.i18n.getMessage('alertAttrName'));
    return;
  }
  if (!value) {
    alert(chrome.i18n.getMessage('alertAttrValue'));
    return;
  }
  
  if (!currentTag) {
    currentTag = 'div';
    document.getElementById('tagDisplay').textContent = currentTag;
  }
  
  currentAttributes[name] = value;
  renderAttributes(currentTag, currentAttributes);
  updateSelector(currentTag, currentAttributes);
  
  nameInput.value = '';
  valueInput.value = '';
  nameInput.focus();
  
  document.getElementById('addAttrBtn').disabled = true;
});

// ===== Включение/отключение кнопки "Добавить атрибут" =====
document.getElementById('newAttrName').addEventListener('input', toggleAddAttrBtn);
document.getElementById('newAttrValue').addEventListener('input', toggleAddAttrBtn);

function toggleAddAttrBtn() {
  const name = document.getElementById('newAttrName').value.trim();
  const value = document.getElementById('newAttrValue').value.trim();
  document.getElementById('addAttrBtn').disabled = !(name && value);
}

// ===== Редактирование селектора вручную =====
document.getElementById('selectorInput').addEventListener('input', function() {
  const manualSelector = this.value.trim();
  if (manualSelector) {
    checkSelectorCount(manualSelector);
  }
});

// ===== Добавление правила с проверкой =====
document.getElementById('addRule').addEventListener('click', function() {
  const selector = document.getElementById('selectorInput').value.trim();
  if (!selector) {
    alert(chrome.i18n.getMessage('alertEmptySelector'));
    return;
  }
  
  const modeRadios = document.querySelectorAll('input[name="blockMode"]');
  let blockMode = 'hide';
  for (const radio of modeRadios) {
    if (radio.checked) {
      blockMode = radio.value;
      break;
    }
  }
  
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs || !tabs[0]) {
      alert(chrome.i18n.getMessage('alertNoTab'));
      return;
    }

    // НОВОЕ: Получаем домен текущей страницы
    let currentDomain = '';
    if (tabs[0].url) {
      currentDomain = getDomainFromUrl(tabs[0].url);
    }
    
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (sel) => {
        try {
          return document.querySelectorAll(sel).length;
        } catch (e) {
          return -1;
        }
      },
      args: [selector]
    }, function(results) {
      if (chrome.runtime.lastError) {
        alert(chrome.i18n.getMessage('alertCheckError'));
        return;
      }
      
      const count = results && results[0] ? results[0].result : -1;
      
      if (count === -1) {
        alert(chrome.i18n.getMessage('alertInvalidSelector'));
        return;
      }
      
      if (count === 0) {
        const confirmMsg = chrome.i18n.getMessage('confirmZeroElements');
        if (!confirm(confirmMsg)) {
          return;
        }
      }
      
      if (count > 1) {
        const confirmMsg = chrome.i18n.getMessage('confirmMultipleElements').replace('{count}', count);
        if (!confirm(confirmMsg)) {
          return;
        }
      }
      
      chrome.storage.local.get(['rules'], function(result) {
        const rules = result.rules || [];
        if (rules.some(rule => rule.selector === selector)) {
          alert(chrome.i18n.getMessage('alertRuleExists'));
          return;
        }

        // НОВОЕ: Сохраняем домен вместе с правилом
        rules.push({ 
          selector: selector,
          mode: blockMode,
          domain: currentDomain  // ← СОХРАНЯЕМ ДОМЕН
        });

        chrome.storage.local.set({ rules }, function() {
          document.getElementById('status').textContent = chrome.i18n.getMessage('ruleAdded');
          document.getElementById('status').style.color = 'green';
          renderRulesList();
        });
      });
    });
  });
});

// ===== Функция получения домена без регулярок =====
function getDomainFromUrl(url) {
  // Убираем протокол (http://, https://)
  let domain = url;
  
  // Ищем "://" и удаляем всё до него включительно
  const protocolIndex = domain.indexOf('://');
  if (protocolIndex !== -1) {
    domain = domain.substring(protocolIndex + 3);
  }
  
  // Ищем первый слеш "/" и удаляем всё после него включительно
  const slashIndex = domain.indexOf('/');
  if (slashIndex !== -1) {
    domain = domain.substring(0, slashIndex);
  }
  
  // Ищем "www." и удаляем его
  if (domain.startsWith('www.')) {
    domain = domain.substring(4);
  }
  
  return domain;
}

// ===== Отображение списка правил с группировкой по сайтам =====
function renderRulesList() {
  chrome.storage.local.get(['rules'], function(result) {
    let rules = result.rules || [];
    
    const container = document.getElementById('rulesContainer');
    container.innerHTML = '';
    
    if (rules.length === 0) {
      const emptyMsg = document.createElement('div');
      emptyMsg.style.color = '#999';
      emptyMsg.style.fontStyle = 'italic';
      emptyMsg.textContent = chrome.i18n.getMessage('noRules');
      container.appendChild(emptyMsg);
      return;
    }
    
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      let currentDomain = '';
      if (tabs && tabs[0] && tabs[0].url) {
        currentDomain = getDomainFromUrl(tabs[0].url);
      }
      
      // Разделяем правила на текущий сайт и остальные
      const currentSiteRules = [];
      const otherRules = [];
      
      rules.forEach(rule => {
        // Проверяем домен правила
        const ruleDomain = rule.domain || '';
        
        if (ruleDomain && ruleDomain === currentDomain) {
          currentSiteRules.push(rule);
        } else {
          otherRules.push(rule);
        }
      });
      
      // Если есть правила для текущего сайта — показываем их
      if (currentSiteRules.length > 0) {
        const siteLabel = currentDomain || chrome.i18n.getMessage('thisSite');
        const title = chrome.i18n.getMessage('rulesForThisSite').replace('{site}', siteLabel);
        renderRuleGroup(container, title, currentSiteRules);
      }
      
      // Если есть правила для других сайтов — показываем их
      if (otherRules.length > 0) {
        const title = chrome.i18n.getMessage('rulesForOtherSites');
        renderRuleGroup(container, title, otherRules);
      }
      
      // Если почему-то ничего не отобразилось — показываем все правила
      if (currentSiteRules.length === 0 && otherRules.length === 0) {
        renderRuleGroup(container, chrome.i18n.getMessage('allSitesRules'), rules);
      }
    });
  });
}

// ===== Вспомогательная функция для отрисовки группы правил =====
function renderRuleGroup(container, title, rules) {
  const groupDiv = document.createElement('div');
  groupDiv.className = 'rules-group';
  
  const titleDiv = document.createElement('div');
  titleDiv.className = 'group-title';
  titleDiv.textContent = title + ' (' + rules.length + ')';
  groupDiv.appendChild(titleDiv);
  
  const ul = document.createElement('ul');
  
  rules.forEach((rule, index) => {
    const li = document.createElement('li');
    const modeLabel = rule.mode === 'remove' ? '🗑️' : '👻';
    li.textContent = `${modeLabel} ${rule.selector}`;
    
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = chrome.i18n.getMessage('deleteBtn');
    deleteBtn.addEventListener('click', function() {
      // Находим индекс правила в общем списке
      chrome.storage.local.get(['rules'], function(result) {
        const allRules = result.rules || [];
        // Ищем по селектору (предполагаем, что селекторы уникальны)
        const idx = allRules.findIndex(r => r.selector === rule.selector);
        if (idx !== -1) {
          allRules.splice(idx, 1);
          chrome.storage.local.set({ rules: allRules }, renderRulesList);
        }
      });
    });
    li.appendChild(deleteBtn);
    ul.appendChild(li);
  });
  
  groupDiv.appendChild(ul);
  container.appendChild(groupDiv);
}

// ===== Обновление подсказки при переключении режима =====
document.querySelectorAll('input[name="blockMode"]').forEach(radio => {
  radio.addEventListener('change', updateModeHint);
});

// ===== Очистка всех правил =====
document.getElementById('clearRules').addEventListener('click', function() {
  if (confirm(chrome.i18n.getMessage('confirmClearRules'))) {
    chrome.storage.local.clear(function() {
      if (chrome.runtime.lastError) {
        alert(chrome.i18n.getMessage('alertClearError') + ': ' + chrome.runtime.lastError.message);
        return;
      }
      
      document.getElementById('status').textContent = '🧹 ' + chrome.i18n.getMessage('rulesCleared');
      document.getElementById('status').style.color = 'orange';
      renderRulesList();
    });
  }
});

// ===== ИМПОРТ ПРАВИЛ =====
document.getElementById('importRules').addEventListener('click', function() {
  // Открываем окно импорта
  chrome.windows.create({
    url: chrome.runtime.getURL('import.html'),
    type: 'popup',
    width: 500,
    height: 450,
    focused: true
  });
});

// ===== Слушаем обновления правил из import.html =====
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === 'rulesUpdated') {
    renderRulesList();
    document.getElementById('status').textContent = '✅ ' + chrome.i18n.getMessage('rulesImported');
    document.getElementById('status').style.color = 'green';
  }
});

// ===== Загрузка списка правил и локализация при открытии popup =====
document.addEventListener('DOMContentLoaded', function() {
  localizeUI();
  renderRulesList();
});