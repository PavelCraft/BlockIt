// ===== Состояние =====
let importedRules = [];

// ===== DOM-элементы =====
const jsonInput = document.getElementById('jsonInput');
const fileInput = document.getElementById('fileInput');
const loadFileBtn = document.getElementById('loadFileBtn');
const clearBtn = document.getElementById('clearBtn');
const replaceBtn = document.getElementById('replaceBtn');
const addBtn = document.getElementById('addBtn');
const closeBtn = document.getElementById('closeBtn');
const statusDiv = document.getElementById('status');
const fileInfo = document.getElementById('fileInfo');

// ===== Локализация окна импорта =====
function localizeImport() {
  // Переводим все элементы с data-i18n
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const message = chrome.i18n.getMessage(key);
    if (message) {
      el.textContent = message;
    }
  });
  
  // Переводим все плейсхолдеры с data-i18n-placeholder
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    const message = chrome.i18n.getMessage(key);
    if (message) {
      el.placeholder = message;
    }
  });
}

// ===== Вспомогательные функции =====
function showStatus(message, type) {
  statusDiv.textContent = message;
  statusDiv.className = type;
  statusDiv.style.display = 'block';
}

function hideStatus() {
  statusDiv.style.display = 'none';
}

function parseRules(jsonText) {
  const data = JSON.parse(jsonText);
  let rules = [];
  
  if (data.rules && Array.isArray(data.rules)) {
    rules = data.rules;
  } else if (Array.isArray(data)) {
    rules = data;
  } else {
    throw new Error('Неверный формат. Ожидается массив правил или объект с полем "rules".');
  }
  
  rules.forEach((rule, index) => {
    if (!rule.selector) {
      throw new Error(`Правило #${index + 1} не содержит поля "selector".`);
    }
  });
  
  return rules;
}

function importRules(replace) {
  const jsonText = jsonInput.value.trim();
  if (!jsonText) {
    showStatus('⚠️ ' + chrome.i18n.getMessage('alertNoRulesInFile'), 'error');
    return;
  }
  
  try {
    const rules = parseRules(jsonText);
    
    if (rules.length === 0) {
      showStatus('⚠️ ' + chrome.i18n.getMessage('alertNoRulesInFile'), 'error');
      return;
    }
    
    chrome.storage.local.get(['rules'], function(result) {
      let existingRules = result.rules || [];
      
      if (replace) {
        existingRules = rules;
        showStatus(`✅ Заменено ${rules.length} правил.`, 'success');
      } else {
        const existingSelectors = new Set(existingRules.map(r => r.selector));
        let addedCount = 0;
        
        rules.forEach(rule => {
          if (!existingSelectors.has(rule.selector)) {
            existingRules.push(rule);
            existingSelectors.add(rule.selector);
            addedCount++;
          }
        });
        
        if (addedCount === 0) {
          showStatus('⚠️ Все правила уже существуют. Ничего не добавлено.', 'error');
          return;
        }
        showStatus(`✅ Добавлено ${addedCount} новых правил. Всего: ${existingRules.length}.`, 'success');
      }
      
      chrome.storage.local.set({ rules: existingRules }, function() {
        chrome.runtime.sendMessage({ type: 'rulesUpdated' });
      });
    });
    
  } catch (error) {
    showStatus('❌ Ошибка: ' + error.message, 'error');
  }
}

// ===== ИСПРАВЛЕННЫЙ ОБРАБОТЧИК ФАЙЛА =====
loadFileBtn.addEventListener('click', function() {
  fileInput.click();
});

fileInput.addEventListener('change', async function(event) {
  const file = event.target.files[0];
  console.log(file);
  try {
    const text = await file.text();
    console.log("file.text length =", text.length);
  } catch (e) {
    console.error("file.text failed", e);
  }
  console.log(event.target.files);
  if (!file) {
    console.log('[BlockIt] Файл не выбран');
    return;
  }
  
  console.log('[BlockIt] Выбран файл:', file.name, 'размер:', file.size, 'байт');
  console.log(file);
  console.log(file.name);
  console.log(file.type);
  console.log(file.lastModified);
  console.dir(file);
  
  // Проверяем, что файл не пустой
  if (file.size === 0) {
    showStatus('⚠️ Файл пустой (0 байт). Выберите корректный файл.', 'error');
    fileInfo.textContent = '⚠️ Файл пустой';
    return;
  }
  
  fileInfo.textContent = `📄 Файл: ${file.name} (${(file.size / 1024).toFixed(1)} КБ)`;
  
  const reader = new FileReader();
  
  // Обработчик успешного чтения
  reader.onload = function(e) {
    try {
      const content = e.target.result;
      console.log('[BlockIt] Файл прочитан, длина:', content.length, 'символов');
      
      // Проверяем, что содержимое не пустое
      if (!content || content.trim() === '') {
        showStatus('⚠️ Файл не содержит данных.', 'error');
        return;
      }
      
      jsonInput.value = content;
      hideStatus();
      
      // Пробуем распарсить для проверки
      try {
        const rules = parseRules(content);
        fileInfo.textContent = `📄 Файл: ${file.name} (${(file.size / 1024).toFixed(1)} КБ) — найдено правил: ${rules.length}`;
      } catch (parseError) {
        fileInfo.textContent = `📄 Файл: ${file.name} — ⚠️ ${parseError.message}`;
        showStatus('⚠️ ' + parseError.message, 'error');
      }
      
    } catch (error) {
      console.error('[BlockIt] Ошибка чтения файла:', error);
      showStatus('❌ Ошибка чтения файла: ' + error.message, 'error');
      fileInfo.textContent = '❌ Ошибка чтения';
    }
  };
  
  // Обработчик ошибки чтения
  reader.onerror = function(e) {
    console.error('[BlockIt] Ошибка FileReader:', e);
    showStatus('❌ Ошибка чтения файла: ' + (reader.error ? reader.error.message : 'неизвестная ошибка'), 'error');
    fileInfo.textContent = '❌ Ошибка чтения';
  };
  
  reader.onloadend = function () {
    console.log("loadend");
    event.target.value = "";
    };

    reader.readAsText(file);
});

// ===== Остальные обработчики =====
clearBtn.addEventListener('click', function() {
  jsonInput.value = '';
  fileInfo.textContent = '';
  hideStatus();
  jsonInput.focus();
});

replaceBtn.addEventListener('click', function() {
  importRules(true);
});

addBtn.addEventListener('click', function() {
  importRules(false);
});

closeBtn.addEventListener('click', function() {
  window.close();
});

jsonInput.addEventListener('keydown', function(e) {
  if (e.ctrlKey && e.key === 'Enter') {
    e.preventDefault();
    addBtn.click();
  }
});

// ===== Загрузка окна =====
document.addEventListener('DOMContentLoaded', function() {
  localizeImport();
  jsonInput.focus();
});